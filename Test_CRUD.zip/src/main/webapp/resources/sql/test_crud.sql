create database test_crud;
use test_crud;

create table member(
  id varchar(10) primary key,
  pw varchar(10)
);

select * from member;
